<?php
    //session code
	session_start();
	//connction code
	$conn = new mysqli("localhost", "root", "", "corr_db");
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	mysqli_set_charset($conn, 'utf8');
	
	if (!isset($_SESSION['id'])) {
		header("Location:login.php");
		exit;
	}
	//getting username
	$e_id=$_SESSION['id'];
	$query = mysqli_query($conn, "select * from user where id='$e_id'")or die(mysqli_error($conn));
	$row = mysqli_fetch_array($query);
	$en = $row['name'];
	
	$divisions_n = null;
	
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <title>employee page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!--<link rel="stylesheet" type="text/css" href="e_style.css">-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  
  <style>
    @import url('https://fonts.googleapis.com/css?family=Cairo&display=swap');
    :root{
	    --white: #fff;
	    --grey1: #F1F2F1;
	    --grey2: #5B5D5B;
	    --black1: #222;
	    --black2: #999;
    }
    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        font-family: 'Cairo', sana-serif;
        <!--position: right;-->
    }
    body{
	    min-height: 100vh;
	    width: 100%;
	    <!--background-color: var(--grey1);-->
    }
	.sidebar{
		position: fixed;
		height: 100%;
		width: 190px;
		background-color: var(--black1);
		float: right;
	}
	.sidebar.active{
		width: 30px;
	}
    .sidebar .user-details{
		height: 80px;
		width: 100%;
	}
	.sidebar .user-details ion-icon{
		font-size: 30px;
		font-weight: 500;
		color: var(--white);
		float: right;
		margin-top: 15px;
		margin-right: 10px;
	}
	.sidebar .user-details .user_name{
		font-size: 20px;
		font-weight: 500;
		color: var(--white);
		float: right;
		margin-right: 5px;
		margin-top: 17px;
	}
	.sidebar .nav-links{
		margin-top: -12px;
		float: right;
		margin-right: 10px;
    }
    .sidebar .nav-links li{
		height: 50px;
		width: 129%;
		list-style: none;
	}
	.sidebar .nav-links li a:hover{
		background-color: var(--grey2);
	}
	.sidebar .nav-links li a{
		height: 100%;
		width: 123%;
		display: flex;
		align-items: center;
		text-decoration: none;
		transition: all 0.4s ease;
	}
	.sidebar .nav-links li a ion-icon{
		min-width: 30px;
		height: 20px;
		text-align: center;
		color: var(--white);
		font-size: 18px;
	}
    .sidebar .nav-links li a .link_name{
		color: var(--white);
		font-size: 15px;
		font-weight: 400;
	}
    .out-link{
		margin-top: 50px;
	}
	.main-option{
		background: var(--grey2);
		width: 123px;
	}
	.pageone{
		background: var(--grey1);
		position: relative;
		min-height: 200vh;
		width: calc(100% - 190px);
		right: 190px;
	}
    .pageone nav{
		height: 50px;
		background: var(--white);
		padding: 0 20px;
		display: flex;
        align-items: center;
        justify-content: space-between;		
	}
	.sidebar-button{
		width: 260px;
	}
    .pageone nav .sidebar-button{
		display: flex;
		align-items: center;
		font-size: 18px;
		font-weight: 500;
	}
    .pageone nav .sidebar-button ion-icon{
		font-size: 27px;
	}
    .pageone nav .search-box{
		height: 40px;
		width: 630px;
		margin: 0 40px;
		position: relative;
	}
	nav .search-box input{
		height:30px;
		width: 595px;
		align-items: center;
		border-radius: 4px;
		margin-top: 5px;
		padding: 10 0px;
		font-size: 18px;
		background: var(--grey1);
		color: var(--black1);
		border: 2px solid var(--grey1);
		outline: none;
	}
    nav .search-box ion-icon{
		position: absolute;
		height: 25px;
		width: 25px;
		margin-top: 8px;
		margin-right: 5px;
		background: #64BBE4;
		color: #fff;
		border-radius: 4px;
		transform: translateY(-3%);
	}
	.home-contine-first{
		float: right;
		width: 850px;
		height: 410px;
		margin-right: 25px;
		margin-top: 40px;
		background: #fff;
		border-radius: 8px;
		box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
	}
	.home-contine-first .main-title-first span{
		color: var(--black1);
		float: right;
		font-size: 18px;
		margin-right: 15px;
		margin-top: 15px;
	}
	.button {
		cursor: pointer;
		background-color: #3D3A37;
		color: #fff;
		text-decoration: none;
		border: 2px solid;
		font-weight: bold;
		padding: 5px 50px;
		border-radius: 6px;
		transition: .4s;
		margin-left: 35px;
	}
	.button:hover{
		background: transparent;
		border: 2px solid #3D3A37;
		cursor: pointer;
		color: #3D3A37;
	}
	.mass{
		background: green;
		color: white;
	}
	.home-contine{
		float: right;
		width: 850px;
		height: 50px;
		margin-right: 25px;
		margin-top: 40px;
	}
	.buttona {
		cursor: pointer;
		background-color: #3D3A37;
		color: #fff;
		text-decoration: none;
		border: 2px solid;
		font-weight: bold;
		padding: 5px 50px;
		border-radius: 6px;
		transition: .4s;
		margin-left: 35px;
	}
	.home-contine-table{
		float: right;
		width: 850px;
		height: 415px;
		margin-right: 25px;
		margin-top: 40px;
		background: #fff;
		border-radius: 8px;
		box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
		overflow-y: scroll;
        overflow-x: hidden;
	}
	.home-contine-table .main-title-table span{
		color: var(--black1);
		float: right;
		font-size: 18px;
		margin-right: 15px;
		margin-top: 15px;
	}
  </style>

</head>
<body>
    <!-- dashboard barcode start here -->
    <div class="sidebar">
	    <div class="user-details">
		    <ion-icon name="person-circle-outline"></ion-icon>
			<span class="user_name"><?php echo $en; ?></span>
		</div>
		<ul class="nav-links">
		    <li>
			    <a href="#" class="main-option">
				    <ion-icon name="menu-outline"></ion-icon>
					<span class="link_name">خيارات التحكم</span>
				</a>
			</li>
		    <li>
			    <a href="superadmin.php">
				    <ion-icon name="mail-outline"></ion-icon>
					<span class="link_name">صندوق الوارد</span>
				</a>
			</li>
		    <li>
			    <a href="s_monitoring.php">
				    <ion-icon name="albums-outline"></ion-icon>
					<span class="link_name">صندوق المتابعة</span>
				</a>
			</li>
		    <li>
			    <a href="s_create_mass.php">
				    <ion-icon name="create-outline"></ion-icon>
					<span class="link_name">إنشاء مراسلة</span>
				</a>
			</li>
		    <li>
			    <a href="s_send_mass.php">
				    <ion-icon name="paper-plane-outline"></ion-icon>
					<span class="link_name">تحويل مراسلة</span>
				</a>
			</li>
		    <li>
			    <a href="s_achievements.php">
				    <ion-icon name="clipboard-outline"></ion-icon>
					<span class="link_name">تقرير الإنجاز</span>
				</a>
			</li>
		    <li>
			    <a href="s_achievements_employee.php">
				    <ion-icon name="reader-outline"></ion-icon>
					<span class="link_name">تقرير إنجاز الموظفين</span>
				</a>
			</li>
		    <li>
			    <a href="setting.php">
				    <ion-icon name="apps-outline"></ion-icon>
					<span class="link_name">إعدادات النظام</span>
				</a>
			</li>
		    <li>
			    <a href="logout.php">
				    <ion-icon name="log-out-outline"></ion-icon>
					<span class="link_name">تسجيل الخروج</span>
				</a>
			</li>
		</ul>
	</div>
	<!-- page content code start here -->
	<section class="pageone">
	    <nav>
		    <div class="sidebar-button">
				<span class="dashboard" style="font-size: 17px;">قسم التعيينات والتنقلات</span>
			</div>
		    <div class="search-box">
			    <input type="text" placeholder="  ابحث الآن ...">
				<ion-icon name="search-outline"></ion-icon>
		    </div>
		</nav>
		<!-- first div for add new divisions -->
		<div class="home-contine-first">
		    <div class="main-title-first">
				<form method="post" accept-charset="utf-8">
				<br>
				<span>إضافة شعبة جديدة :</span><br><br>
				    <span style="color: #2294D1; margin-left: 10px; margin-top: 16px;">يرجى إدخال أسم الشعبة :</span>
					<input type="text" name="d_name" id="rn" class="form-control" placeholder="أدخل أسم الشعبة ..."  style="height: 40px; width: 600px; margin-top: 10px;"><br>
				    <button class="button" type="submit" name="add">ضافة</button><br><br><br>
					<?php
					    if (isset($_POST['add'])){
							
						    $d_name = $_POST['d_name'];	
							$sq5 = "insert into divisions (name) values ('".$d_name."');";
		                    $result3 = mysqli_query($conn, $sq5);
							$v = "mass";
							if($result3){
								echo '<center><p class="'.$v.'">لقد تم إضافة الشعبة بنجاح<p></center>';
							}
						}
					?>
				<span>تحديث الشعب :</span><br><br>
				    <span style="color: #2294D1; margin-left: 60px; margin-top: 16px;">يرجى إختيار شعبة :</span>
					<!-- code to get all divisions name -->
				    <select name = "divisions_n" class="form-control" style="height: 40px; width: 600px; margin-top: 10px;">
                        <option value = "" disabled selected>-- قائمة أسماء الشعبات --</option>
		                    <?php 
				                $sql1 = "select * from divisions ";
				                $result1 = mysqli_query($conn, $sql1);
				
				                if($result1){
					                while($row = mysqli_fetch_assoc($result1)){
					                    $d_id = $row['id'];
										$d_name = $row['name'];
									    ?>
                                        <option value="<?php echo $d_id;?>"><?php echo $d_name;?></option>
									    <?php
				                    }
					
				                }
		                    ?>
                    </select>
				    <br>
				    <button class="button" type="submit" name="nextone">التالي</button>
				</form>
			</div>
		</div>
		<?php 
		    if(isset($_POST["nextone"])){
				$divisions_n = $_POST['divisions_n'];
                $_SESSION['divisions_n'] = $divisions_n;
				echo "<script>window.location.href='divisions_setting_next.php';</script>";
				
			}
		?>
		<!-- second div for show all divisions -->
		<div class="home-contine-table">
		    <div class="main-title-table">
			    <span style="color: #2294D1;">قائمة الشعب بنظام :</span><br><br>
	            <table class="table table-hover" style="font-size: 15px;">
                    <thead style="background-color:#3D3A37; color:white;">
                        <tr>
						    <th class="fw-normal text-center">No.</th>
				            <th class="fw-normal text-center">أسم الشعبة</th>
							<th class="fw-normal text-center">خيارات الإعداد</th>
				        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $i = 0;
                            $sql1 = "select * from divisions";
                            $result1 = mysqli_query($conn, $sql1);
                            if($result1){
						        while($row1 = mysqli_fetch_assoc($result1)){
									
							        $i = $i + 1;
							        $id = $row1['id'];
							        $name = $row1['name'];
									echo    '<tr">
									            <td scope="row" class="text-center">'.$i.'</td>
												<td  class="text-center">'.$name.'</td>
								                <td class="text-center">
			                                        <button class="btn btn-secondary" style="background-color:white; border-color:#3D3A37;"><a href="update_d.php?updateid='.$id.'" style="color:#3D3A37;">تحديث</a></button><button class="btn btn-secondary" style="background-color:#3D3A37;"><a href="delete_d.php?deleteid='.$id.'" style="color:white;">حذف</a></button>
			                                    </td>
									         </tr>';
						        }
					        }						
				        ?>
                    </tbody>
                </table>
			</div>
		</div>
		<br>
		<div class="home-contine">
		    <a href="setting.php" style="color:white;" class="buttona">تراجع</a>
		</div>
	</section>
	
	
	<!-- script link for icon -->
	<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>
</html>
