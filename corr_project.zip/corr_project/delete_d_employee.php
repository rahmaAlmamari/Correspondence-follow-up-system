<?php
    
	$conn = new mysqli("localhost", "root", "", "corr_db");
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	
	if(isset($_GET['deleteid']))
	{
		$de_id = $_GET['deleteid'];
		
		$sql = "delete from divi_emp where id='$de_id'";
		$result = mysqli_query($conn, $sql);
		
		if($result)
		{
			//echo "deleted sucessfully";
			header('location:divisions_setting_next.php');
		}
	    else
	    {
		    die(mysqli_error($conn));
	    }
	}
	
?>