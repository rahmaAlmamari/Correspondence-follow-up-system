﻿-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 17, 2022 at 05:15 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `corr_db`
create database corr_db;
use corr_db;
--

-- --------------------------------------------------------

--
-- Table structure for table `achievements`
--

DROP TABLE IF EXISTS `achievements`;
CREATE TABLE IF NOT EXISTS `achievements` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `f_id` int(4) NOT NULL,
  `registr_no` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `sending_d` date NOT NULL,
  `finishing_d` date DEFAULT NULL,
  `condition_m` varchar(10) NOT NULL,
  `evaluation` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `for_if_fk` (`f_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `achievements`
--

INSERT INTO `achievements` (`id`, `f_id`, `registr_no`, `subject`, `sending_d`, `finishing_d`, `condition_m`, `evaluation`) VALUES
(21, 6, '11223344', 'التجربة رقم أربعة', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(22, 6, '1112220', 'التجربة خمسة', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(23, 6, '999000', 'التجربة ستة', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(24, 6, '777777', 'تجربة رقم سبعة لا تحتاج رد', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(25, 6, '888888', 'تجربة ثمانية', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(26, 6, '111110', 'تجربة تسعة لا تحتاج رد من الموظف', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(27, 8, '111110', 'تجربة تسعة لا تحتاج رد من الموظف', '2022-07-16', '2022-07-16', 'مكتمل', 'فوق المتوقع'),
(28, 14, '1234567890', 'اجازة إعتيادية لحراس مدرسة عائشة بنت سعد', '2022-07-17', '2022-07-17', 'مكتمل', 'فوق المتوقع'),
(29, 6, '1234567890', 'اجازة إعتيادية لحراس مدرسة عائشة بنت سعد', '2022-07-17', '2022-07-17', 'مكتمل', 'فوق المتوقع'),
(30, 6, '1234567898765', 'هذه تجربة فقط ', '2022-07-17', '2022-07-17', 'مكتمل', 'فوق المتوقع');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

DROP TABLE IF EXISTS `divisions`;
CREATE TABLE IF NOT EXISTS `divisions` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `name`) VALUES
(1, 'التنقلات'),
(2, 'التعيينات'),
(3, 'الاجر اليومي'),
(4, 'البصمة'),
(5, 'الحراس');

-- --------------------------------------------------------

--
-- Table structure for table `divi_emp`
--

DROP TABLE IF EXISTS `divi_emp`;
CREATE TABLE IF NOT EXISTS `divi_emp` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `d_id` int(4) NOT NULL,
  `e_id` int(4) NOT NULL,
  `e_name` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `divi_id_fk` (`d_id`),
  KEY `e_id` (`e_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divi_emp`
--

INSERT INTO `divi_emp` (`id`, `d_id`, `e_id`, `e_name`) VALUES
(1, 1, 4, 'محمد البلوشي'),
(2, 1, 5, 'سليمان ال عبد السلام'),
(3, 1, 6, 'حسن القطيطي'),
(4, 1, 7, 'عائشة العبرية'),
(6, 2, 9, 'أمنة الجابرية'),
(7, 2, 10, 'سلوى المقبالية'),
(8, 2, 11, 'خديجة المعمرية'),
(9, 2, 12, 'شما المخمرية'),
(10, 2, 13, 'شيخة الجابرية'),
(11, 3, 9, 'أمنة الجابرية'),
(12, 3, 10, 'سلوى المقبالية'),
(13, 3, 11, 'خديجة المعمرية'),
(14, 3, 12, 'شما المخمرية'),
(15, 3, 13, 'شيخة الجابرية'),
(16, 4, 6, 'حسن القطيطي'),
(17, 4, 5, 'سليمان ال عبد السلام'),
(18, 4, 10, 'سلوى المقبالية'),
(20, 5, 14, 'سالم الرحيلي'),
(21, 5, 6, 'حسن القطيطي'),
(22, 5, 15, 'حسن الفارسي'),
(25, 1, 8, 'شيماء العلوية'),
(26, 4, 8, 'شيماء العلوية');

-- --------------------------------------------------------

--
-- Table structure for table `divi_proc`
--

DROP TABLE IF EXISTS `divi_proc`;
CREATE TABLE IF NOT EXISTS `divi_proc` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `d_id` int(4) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `divi_id_fk` (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divi_proc`
--

INSERT INTO `divi_proc` (`id`, `d_id`, `description`) VALUES
(2, 1, 'رفع تصور نقل'),
(3, 1, 'سحب قرار نقل'),
(4, 1, 'دراسة مقترح نقل\\ندب بالتبادل'),
(5, 1, 'إدراج قرار نقل\\ندب في البوابة'),
(6, 1, 'إلغاء نقل\\ندب في البوابة'),
(7, 1, 'إعداد مخاطبة للوزارة'),
(8, 1, 'إعداد مخاطبة دائرة'),
(9, 1, 'إعداد مخاطة لمدرسة'),
(10, 1, 'تحديث بيانات الموارد البشرية بالنظام'),
(11, 1, 'كشوف الندب الخارجي'),
(12, 1, 'كشوف النقل الخارجي'),
(13, 1, 'سحب قرار ندب '),
(14, 1, 'رفع تصور ندب'),
(15, 2, 'استكمال إجراءات التعيين'),
(16, 2, 'إدخال البيانات في النظام المالي'),
(17, 2, 'إدخال البيانات في البوابة'),
(18, 2, 'إعداد مخاطبة للوزارة'),
(19, 2, 'إعداد مخاطبة لدائرة'),
(20, 2, 'إعداد مخاطبة لمدرسة'),
(21, 3, 'إعداد مخاطبة للوزارة'),
(22, 3, 'إعداد مخاطبة لدائرة'),
(23, 3, 'إعداد مخاطبة لمدرسة'),
(24, 3, 'إدراج بيانات المتقدمين بالأجر اليومي'),
(25, 3, 'طلب الموافقات الأمنية'),
(26, 3, 'دراسة طلبات المدارس بالأجر اليومي'),
(27, 3, 'العقود بالأجر اليومي'),
(28, 3, 'طلب الارتباط المالي'),
(29, 3, 'الدرجات الشاغرة'),
(30, 3, 'حصر الإجازات الطويلة'),
(31, 4, 'تفعيل البصمة للجدد'),
(32, 4, 'تفعيل البصمة للمنقولين'),
(33, 4, 'تفعيل البصمة للمنتدبين'),
(34, 4, 'تحويل البصمة من مدرسة لأخرى'),
(36, 5, 'إعداد مخاطبة للوزارة'),
(37, 5, 'إعداد مخاطبة لدائرة'),
(38, 5, 'إعداد مخاطبة لمدرسة'),
(39, 5, 'إدراج بيانات المتقدمين بالأجر اليومي '),
(40, 5, 'طلب الموافقات الأمنية'),
(41, 5, 'دراسة طلبات المدراس بالأجر '),
(42, 5, 'العقود بالأجر اليومي'),
(43, 5, 'طلب الارتباط المالي'),
(47, 5, 'مقترح نقل حارس حكومي'),
(48, 1, 'دراسة وضع مدرسة ما'),
(49, 4, 'إرسال كشف البصمة للجهات المعنية');

-- --------------------------------------------------------

--
-- Table structure for table `monitoring`
--

DROP TABLE IF EXISTS `monitoring`;
CREATE TABLE IF NOT EXISTS `monitoring` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `f_id` int(4) NOT NULL,
  `registr_no` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `to_who` varchar(30) NOT NULL,
  `sending_d` date NOT NULL,
  `state` varchar(15) NOT NULL,
  `to_id` int(4) NOT NULL,
  `from_who` varchar(30) NOT NULL,
  `finish_d` date DEFAULT NULL,
  `reply_state` varchar(30) DEFAULT NULL,
  `d_id` int(4) NOT NULL,
  `reply_d` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `for_id_fk` (`f_id`),
  KEY `to_id_fk` (`to_id`),
  KEY `divisions_id_fk` (`d_id`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `monitoring`
--

INSERT INTO `monitoring` (`id`, `f_id`, `registr_no`, `subject`, `to_who`, `sending_d`, `state`, `to_id`, `from_who`, `finish_d`, `reply_state`, `d_id`, `reply_d`) VALUES
(59, 4, '11223344', 'التجربة رقم أربعة', 'حسن القطيطي', '2022-07-16', 'منجز', 6, 'محمد البلوشي', '2022-07-16', 'لا تحتاج', 1, '2022-07-16'),
(60, 4, '1112220', 'التجربة خمسة', 'حسن القطيطي', '2022-07-16', 'منجز', 6, 'محمد البلوشي', '2022-07-16', 'تحتاج', 1, '2022-07-16'),
(61, 4, '999000', 'التجربة ستة', 'حسن القطيطي', '2022-07-16', 'منجز', 6, 'محمد البلوشي', '2022-07-16', 'لا تحتاج', 1, '2022-07-16'),
(62, 4, '999000', 'التجربة ستة', 'شيماء العلوية', '2022-07-16', 'قيد التنفيذ', 8, 'محمد البلوشي', NULL, 'لا تحتاج', 1, '2022-07-16'),
(63, 4, '777777', 'تجربة رقم سبعة لا تحتاج رد', 'حسن القطيطي', '2022-07-16', 'منجز', 6, 'محمد البلوشي', '2022-07-16', 'لا تحتاج', 1, '2022-07-16'),
(64, 4, '888888', 'تجربة ثمانية', 'حسن القطيطي', '2022-07-16', 'منجز', 6, 'محمد البلوشي', '2022-07-16', 'لا تحتاج', 1, '2022-07-16'),
(65, 4, '888888', 'تجربة ثمانية', 'شيماء العلوية', '2022-07-16', 'منجز', 8, 'محمد البلوشي', NULL, 'تحتاج', 1, '2022-07-16'),
(66, 4, '111110', 'تجربة تسعة لا تحتاج رد من الموظف', 'حسن القطيطي', '2022-07-16', 'منجز', 6, 'محمد البلوشي', '2022-07-16', 'تحتاج', 1, '2022-07-16'),
(67, 4, '111110', 'تجربة تسعة لا تحتاج رد من الموظف', 'شيماء العلوية', '2022-07-16', 'منجز', 8, 'محمد البلوشي', '2022-07-16', 'تحتاج', 1, '2022-07-16'),
(68, 4, '1234567890', 'اجازة إعتيادية لحراس مدرسة عائشة بنت سعد', 'سالم الرحيلي', '2022-07-17', 'منجز', 14, 'محمد البلوشي', '2022-07-17', 'لا تحتاج', 5, '2022-07-17'),
(69, 4, '1234567890', 'اجازة إعتيادية لحراس مدرسة عائشة بنت سعد', 'حسن القطيطي', '2022-07-17', 'منجز', 6, 'محمد البلوشي', '2022-07-17', 'لا تحتاج', 5, '2022-07-17'),
(70, 4, '1234567898765', 'هذه تجربة فقط ', 'حسن القطيطي', '2022-07-17', 'منجز', 6, 'محمد البلوشي', '2022-07-17', 'لا تحتاج', 1, '2022-07-17');

-- --------------------------------------------------------

--
-- Table structure for table `monitoring_reply`
--

DROP TABLE IF EXISTS `monitoring_reply`;
CREATE TABLE IF NOT EXISTS `monitoring_reply` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `m_id` int(10) NOT NULL,
  `f_date` date NOT NULL,
  `f_reply` varchar(1000) NOT NULL,
  `s_date` date DEFAULT NULL,
  `s_reply` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `monitoring_id_fk` (`m_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `monitoring_reply`
--

INSERT INTO `monitoring_reply` (`id`, `m_id`, `f_date`, `f_reply`, `s_date`, `s_reply`) VALUES
(30, 59, '2022-07-16', '<p style=\"text-align: right;\">هذا لانهاء العمل فقط</p>', NULL, NULL),
(31, 60, '2022-07-16', '<p style=\"text-align: right;\">هذا لإنهاء العمل&nbsp;</p>', '2022-07-16', '<p style=\"text-align: right;\">مجددا هذا لختبار البرنامج فقط</p>'),
(32, 61, '2022-07-16', '<p style=\"text-align: right;\">هذا لإنهاء العمل&nbsp;</p>', '2022-07-16', '<p style=\"text-align: right;\">هذا لتحقق فقط&nbsp;</p>'),
(33, 61, '2022-07-16', '<p style=\"text-align: right;\">هذا التأكد بشكل تام من نجاح العمل</p>', NULL, NULL),
(34, 62, '2022-07-16', '<p style=\"text-align: right;\">هذا لأنهاء العمل</p>', NULL, NULL),
(36, 65, '2022-07-16', '<p style=\"text-align: right;\">هذا للأختبار فقط&nbsp;</p>', '2022-07-16', '<p style=\"text-align: right;\">هذا لإنهاء العمل</p>'),
(37, 66, '2022-07-16', '<p style=\"text-align: right;\">لأنهاء العمل</p>', '2022-07-16', '<p style=\"text-align: right;\">لتأكد فقط</p>'),
(38, 67, '2022-07-16', '<p style=\"text-align: right;\">للأختبار فقط</p>', '2022-07-16', '<p style=\"text-align: right;\">للأختبار فقط</p>'),
(39, 68, '2022-07-17', '<p style=\"text-align: right;\">تم إرسال المخاطبة&nbsp;</p>', NULL, NULL),
(40, 68, '2022-07-17', '<p style=\"text-align: right;\">تم توفير البديل</p>', NULL, NULL),
(41, 69, '2022-07-17', '<p style=\"text-align: right;\">تم تفعيل البصمة</p>', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `procedures`
--

DROP TABLE IF EXISTS `procedures`;
CREATE TABLE IF NOT EXISTS `procedures` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `registr_no` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `followed_p` varchar(100) NOT NULL,
  `from_who` varchar(30) NOT NULL,
  `reply_state` varchar(30) NOT NULL,
  `available_t` int(2) NOT NULL,
  `sending_d` date NOT NULL,
  `f_id` int(4) NOT NULL,
  `from_id` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `f_id` (`f_id`),
  KEY `from_id_fk` (`from_id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `resend_mess`
--

DROP TABLE IF EXISTS `resend_mess`;
CREATE TABLE IF NOT EXISTS `resend_mess` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `f_id` int(4) NOT NULL,
  `registr_no` varchar(20) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `m_id` int(4) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `for_id_fk` (`f_id`),
  KEY `fk_monitoring_id` (`m_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `resend_mess`
--

INSERT INTO `resend_mess` (`id`, `f_id`, `registr_no`, `subject`, `m_id`) VALUES
(35, 4, '999000', 'التجربة ستة', 62);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `email` varchar(40) NOT NULL,
  `name` varchar(30) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_un` (`username`),
  UNIQUE KEY `unique_e` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`, `name`, `type`) VALUES
(4, 'moh456', 'moh456', 'mohammed.albaluchi@gmail.com', 'محمد البلوشي', 'منسق'),
(5, 'sul123', 'sul123', 'suleiman.salam@gmail.com', 'سليمان ال عبد السلام', 'موظف'),
(6, 'has123', 'has123', 'hassan.alqutaiti@gmail.com', 'حسن القطيطي', 'موظف'),
(7, 'ais123', 'ais123', 'aisha.alabri@gmail.com', 'عائشة العبرية', 'موظف'),
(8, 'sha123', 'sha123', 'shaima.alalawi@gmail.com', 'شيماء العلوية', 'موظف'),
(9, 'amn123', 'amn123', 'amna.aljbri@gmali.com', 'أمنة الجابرية', 'موظف'),
(10, 'sal123', 'sal123', 'salwa.almoqbalia@gmail.com', 'سلوى المقبالية', 'موظف'),
(11, 'kha123', 'kha123', 'khadija.almamari@gmail.com', 'خديجة المعمري', 'موظف'),
(12, 'sha456', 'sha456', 'shamma.makhmari@gmail.com', 'شما المخمري', 'موظف'),
(13, 'she123', 'she123', 'sheikha.aljabri@gmail.com', 'شيخة الجابرية', 'موظف'),
(14, 'sal456', 'sal456', 'salem.alrahili@gmail.com', 'سالم الرحيلي', 'موظف'),
(15, 'has456', 'has456', 'hassan.alfarsi@gmail.com', 'حسن الفارسي', 'موظف'),
(16, 'sae123', 'sae123', 'saeed.alshamsi@gmail.com', 'سعيد الشامسي', 'مسؤول مباشر'),
(27, 'rr11', 'rr11', 'rahma.fahad@gmail.com', 'رحمة المعمري', 'منسق');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `achievements`
--
ALTER TABLE `achievements`
  ADD CONSTRAINT `achievements_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `divi_emp`
--
ALTER TABLE `divi_emp`
  ADD CONSTRAINT `divi_emp_ibfk_1` FOREIGN KEY (`d_id`) REFERENCES `divisions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `divi_emp_ibfk_2` FOREIGN KEY (`e_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `divi_proc`
--
ALTER TABLE `divi_proc`
  ADD CONSTRAINT `divi_proc_ibfk_1` FOREIGN KEY (`d_id`) REFERENCES `divisions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `monitoring`
--
ALTER TABLE `monitoring`
  ADD CONSTRAINT `monitoring_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `monitoring_ibfk_2` FOREIGN KEY (`to_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `monitoring_ibfk_3` FOREIGN KEY (`d_id`) REFERENCES `divisions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `monitoring_reply`
--
ALTER TABLE `monitoring_reply`
  ADD CONSTRAINT `monitoring_reply_ibfk_1` FOREIGN KEY (`m_id`) REFERENCES `monitoring` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `procedures`
--
ALTER TABLE `procedures`
  ADD CONSTRAINT `procedures_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `procedures_ibfk_2` FOREIGN KEY (`from_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `resend_mess`
--
ALTER TABLE `resend_mess`
  ADD CONSTRAINT `resend_mess_ibfk_1` FOREIGN KEY (`f_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `resend_mess_ibfk_2` FOREIGN KEY (`m_id`) REFERENCES `monitoring` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
