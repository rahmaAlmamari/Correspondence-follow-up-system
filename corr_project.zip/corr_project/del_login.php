<?php
    //session code
	session_start();
	
    //connection to the db
    $conn = new mysqli("localhost", "root", "", "corr_db");
	
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	//login to the system
	if(isset($_POST['submit']))
	{
		$user_n = $_POST['username'];
		$pass_w = $_POST['password'];
		
		$user = mysqli_real_escape_string($conn, $user_n);
		$pass = mysqli_real_escape_string($conn, $pass_w);
        
		$query = mysqli_query($conn, "select * from user where username = '$user' and password = '$pass'")or die(mysqli_error($conn));
		
		$row = mysqli_fetch_array($query);
		
		$name = $row['username'];
		$counter = mysqli_num_rows($query);
		$id = $row['id'];
		$type_u = $row['type'];
		
		if($counter == 0)
		{
			echo"<script type='text/javascript'>alert('Invalid Username or Password!');document.location='login.php'</script>";
		}
		else
		{
			$_SESSION['id'] = $id;
			$_SESSION['username'] = $name;
			
			//echo "<script type='text/javascript'>document.location='admin.php'</script>";
			if($type_u == "admin")
			{
				header("Location:admin.php");
				exit;
			}
			elseif($type_u == "superadmin")
			{
				header("Location:superadmin.php");
				exit;
			}
			else
			{
				header("Location:employee.php");
				exit;
			}
		}

	}
 ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <title>Corr System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet"></link>
	
	<style>

		.bg{
		    background-image: url('overlay.png'),url('https://i0.wp.com/www.atheer.om/wp-content/uploads/2019/02/D0J2ErfXcAEvzLS.jpg?resize=1140%2C570&ssl=1');
            background-repeat: no-repeat, repeat;
            background-position: center; /* Center the image */
            background-size: cover; /* Resize the background image to cover the entire container */
			width: 100%;
			height: 100vh;
		}
		.form-conatiner{
		    border: 0px solid #fff;
			padding: 50px 40px;
			margin-top: 15vh;
			color: #fff;
			-webkit-box-shadow: -1px 3px 21px 5px rgba(0,0,0,0.75);
            -moz-box-shadow: -1px 3px 21px 5px rgba(0,0,0,0.75);
            box-shadow: -1px 3px 21px 5px rgba(0,0,0,0.75);
			font-family: Cairo;
		}
        .button{
            background-color: #fff;
			color: #626B63;
            border: 2px;			
			text-decoration: none;
			font-weight: bold;
			padding: 8px 45px;
			border-radius: 11px;
			transition: .4s;
        }			
		.button:hover{
            background: transparent;
			color: #fff;
			border: 2px solid #fff;
			cursor: pointer;
			
		}
		
	</style>
</head>
<body>

    <div class="container-fluid bg">
	
	<!-- login form code start here -->
    <div class="container-fluid bg">
	    <div class="row">
		    <div class="col-md-4 col-sm-4 col-xs-12"></div>
			<div class="col-md-4 col-sm-4 col-xs-12">
			<!--form code -->
			    <form class="form-conatiner" method="post">
				    <h1 style="font-weight: bold;"> تسجيل الدخول</h1>
					<br>
				    <div class="form-group">
					    <label>أسم المستخدم</label>
						<input type="text" name="username" id="un" class="form-control" placeholder="أدخل أسم المستخدم الخاص بك .." required>
					</div>
					<div class="form-group">
					    <label>كلمة السر</label>
						<input type="password" name="password" id="pw" class="form-control" placeholder="أدخل كلمة المرور الخاصة بك .." required>   
					</div>
					<center>
					<button type="submit" class="button" name="submit" id="btn">دخول</button>
					</center>
				</form>
			</div>
			<div class="col-md-4 col-sm-4 col-xs-12"></div>
		</div>
	</div>
	
	</div>
	
</body>
</html>

