<?php
    //session code
	session_start();
	
    //connection to the db
    $conn = new mysqli("localhost", "root", "", "corr_db");
	
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	mysqli_set_charset($conn, 'utf8');
	//mysql_query("SET CHARACTER SET UTF8");
	//$c->exec('SET CHARACTER SET UTF8');
	//login to the system
	
	$error = "";
	
	if(isset($_POST['submit']))
	{
		$user_n = $_POST['username'];
		$pass_w = $_POST['password'];
		
		$user = mysqli_real_escape_string($conn, $user_n);
		$pass = mysqli_real_escape_string($conn, $pass_w);
        
		$query = mysqli_query($conn, "select * from user where username = '$user' and password = '$pass'")or die(mysqli_error($conn));
		
		$row = mysqli_fetch_array($query);
		
		$name = $row['username'];
		$counter = mysqli_num_rows($query);
		$id = $row['id'];
		$type_u = $row['type'];
		
		if($counter == 0)
		{
			$error = "اسم المستخدم\كلمة المرور خاطئة!!";
		}
		else
		{
			$_SESSION['id'] = $id;
			$_SESSION['username'] = $name;
			
			//echo "<script type='text/javascript'>document.location='admin.php'</script>";
			if($type_u == "منسق")
			{
				header("Location:admin.php");
				exit;
			}
			elseif($type_u == "مسؤول مباشر")
			{
				header("Location:superadmin.php");
				exit;
			}
			else
			{
				header("Location:employee.php");
				exit;
			}
		}

	}
 ?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <title>Login Page</title>
  <meta charset="utf-8">
  <!--header('content-type:text/html; charset=utf-8')-->
  <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!--<link rel="stylesheet" type="text/css" href="style.css">-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet"></link>
  
  <style>
    body
	{
        height: 100vh;
        background: #D0D3D0 !important;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
	.card
	{
        overflow: hidden;
        border: 0 !important;
        border-radius: 20px !important;
        box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
    }
	.img-left
	{
        width: 45%;
        background: url('overlay.png'),url('https://i0.wp.com/www.atheer.om/wp-content/uploads/2019/02/D0J2ErfXcAEvzLS.jpg?resize=1140%2C570&ssl=1') center;
        background-size: cover;
    }
    .card-body
	{
        padding: 3rem;
    }
    .button{
        background-color: black;
		color: #fff;
        border: 3px;			
		text-decoration: none;
		font-weight: bold;
		padding: 8px 45px;
		border-radius: 11px;
		transition: .4s;
    }			
	.button:hover{
        background: transparent;
		color: black;
		border: 3px solid black;
		cursor: pointer;
			
	}

    .forget-link
	{
        color: #007bff;
        font-weight: bold;
    }

    .forget-link:hover
	{
        color: #0069d9;
        text-decoration: none;
    }
	.form-conatiner
	{
		border: 0px solid #fff;
		color: black;
		font-family: Cairo;
	
	}
	.error{
		background: red;
		color: white;
	}
  </style>

</head>
<body>
    <div class="container bg">
    <div class="row px-3">
      <div class="col-lg-10 col-xl-9 card flex-row mx-auto px-0">
        <div class="img-left d-none d-md-flex"></div>

        <div class="card-body">
		  		<form class="form-conatiner" method="post" accept-charset="utf-8">
				    <center>
				        <h1 style="font-weight: bold;"> تسجيل الدخول</h1>
					</center>
					<br>
				    <div class="form-group">
						<input type="text" name="username" id="un" class="form-control" placeholder="أدخل أسم المستخدم الخاص بك .." required>
					</div>
					<div class="form-group">
						<input type="password" name="password" id="pw" class="form-control" placeholder="أدخل كلمة المرور الخاصة بك .." required>   
					</div>
					<br>
					<center>
					    <button type="submit" class="button" name="submit" id="btn">دخول</button><br><br>
                        <a href="#">
                            هل نسيت كلمة المرورالخاصة بك ؟
                        </a><br><br>
						<p class="error"><?php echo $error; ?></p>
                    </center>
				</form>
        </div>
      </div>
    </div>
  </div>
<span style="font-family: Cairo; color: #EBEFF0; margin-top: 14px; font-size: 13px;">Created in 2022 by: Rahma AL-Mamari</span>
</body>
</html>