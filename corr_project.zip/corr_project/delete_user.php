<?php
    
	$conn = new mysqli("localhost", "root", "", "corr_db");
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	
	if(isset($_GET['deleteid']))
	{
		$user_id = $_GET['deleteid'];
		
		$sql = "delete from user where id='$user_id'";
		$result = mysqli_query($conn, $sql);
		
		if($result)
		{
			//echo "deleted sucessfully";
			header('location:setting.php');
		}
	    else
	    {
		    die(mysqli_error($conn));
	    }
	}
	
?>