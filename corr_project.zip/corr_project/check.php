<!DOCTYPE html>
<!--
Tutorial : Add WYSIWYG HTML Editor to Textarea
Author   : Vikash Kumar Singh
Blog     : phpcluster.com
-->
<html>
<head>
<title>Add WYSIWYG HTML Editor to Textarea on Your Site</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<script src="tinymce_6.0.3/tinymce/js/tinymce/tinymce.min.js"></script>
<script>tinymce.init({ selector:'#pclu-textarea',branding: false });</script>
</head>
<body style="text-align:center;">
<div>
<h1>Add WYSIWYG HTML Editor to Textarea on Your Site</h1> 

<div class="progress">
  <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 75%"></div>
</div>

</div>
</body>
</html>