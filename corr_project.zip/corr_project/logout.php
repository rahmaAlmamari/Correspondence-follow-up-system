<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <title>Corr System</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cairo&display=swap" rel="stylesheet"></link>
	
	
	<style>
    body
	{
        height: 100vh;
        background: #D0D3D0 !important;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
    }
    .logout{
		margin-top: 20px;
		background: white;
		width: 400px;
		height: 200px;
		box-sizing: border-box;
		font-family: 'Cairo', sana-serif;
		border-radius: 6px;
		-webkit-box-shadow: -2px 0px 25px 1px rgba(0,0,0,0.75);
        -moz-box-shadow: -2px 0px 25px 1px rgba(0,0,0,0.75);
        box-shadow: -2px 0px 25px 1px rgba(0,0,0,0.75);
	}
	.content{
		width: 300px;
		font-size: 18px;
		height: 100px;
	}
	</style>
</head>
<body>

    <div>
	    <?php 
		    session_start();
            //connection to the db
            $conn = new mysqli("localhost", "root", "", "corr_db");
	
	        if(!$conn)
	        {
		        die(mysqli_error($conn));
	        }
			
			session_destroy();
			echo'<center>';
			echo'<div class="logout"><br><br><br>';
			echo'<meta http-equiv="refresh" content="2;url=login.php">';
			echo'<div class="content">';
			echo'<span class="itext">يرجى الإنتظار يتم تسجيل خروجك الآن ...!!</span><br><br>';
			echo'<progress max=100 class="w3-blue"><strong>Progress: 60% done.</strong></progress>';
			echo'</div>';
			echo'</div>';
			echo'</center>';
		?>
	</div>
	
</body>
</html>

