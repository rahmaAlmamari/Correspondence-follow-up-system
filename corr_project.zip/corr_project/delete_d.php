<?php
    
	$conn = new mysqli("localhost", "root", "", "corr_db");
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	
	if(isset($_GET['deleteid']))
	{
		$d_id = $_GET['deleteid'];
		
		$sql = "delete from divisions where id='$d_id'";
		$result = mysqli_query($conn, $sql);
		
		if($result)
		{
			//echo "deleted sucessfully";
			header('location:divisions_setting.php');
		}
	    else
	    {
		    die(mysqli_error($conn));
	    }
	}
	
?>