<?php
    //session code
	session_start();
	//connction code
	$conn = new mysqli("localhost", "root", "", "corr_db");
	if(!$conn)
	{
		die(mysqli_error($conn));
	}
	mysqli_set_charset($conn, 'utf8');
	
	if (!isset($_SESSION['id'])) {
		header("Location:login.php");
		exit;
	}
	//getting username
	$e_id=$_SESSION['id'];
	$query = mysqli_query($conn, "select * from user where id='$e_id'")or die(mysqli_error($conn));
	$row = mysqli_fetch_array($query);
	$en = $row['name'];
	
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <title>employee page</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!--<link rel="stylesheet" type="text/css" href="e_style.css">-->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  
  <style>
    @import url('https://fonts.googleapis.com/css?family=Cairo&display=swap');
    :root{
	    --white: #fff;
	    --grey1: #F1F2F1;
	    --grey2: #5B5D5B;
	    --black1: #222;
	    --black2: #999;
    }
    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
        font-family: 'Cairo', sana-serif;
        <!--position: right;-->
    }
    body{
	    min-height: 100vh;
	    width: 100%;
	    <!--background-color: var(--grey1);-->
    }
	.sidebar{
		position: fixed;
		height: 100%;
		width: 190px;
		background-color: var(--black1);
		float: right;
	}
	.sidebar.active{
		width: 30px;
	}
    .sidebar .user-details{
		height: 80px;
		width: 100%;
	}
	.sidebar .user-details ion-icon{
		font-size: 30px;
		font-weight: 500;
		color: var(--white);
		float: right;
		margin-top: 15px;
		margin-right: 10px;
	}
	.sidebar .user-details .user_name{
		font-size: 20px;
		font-weight: 500;
		color: var(--white);
		float: right;
		margin-right: 5px;
		margin-top: 17px;
	}
	.sidebar .nav-links{
		margin-top: -12px;
		float: right;
		margin-right: 10px;
    }
    .sidebar .nav-links li{
		height: 50px;
		width: 129%;
		list-style: none;
	}
	.sidebar .nav-links li a:hover{
		background-color: var(--grey2);
	}
	.sidebar .nav-links li a{
		height: 100%;
		width: 123%;
		display: flex;
		align-items: center;
		text-decoration: none;
		transition: all 0.4s ease;
	}
	.sidebar .nav-links li a ion-icon{
		min-width: 30px;
		height: 20px;
		text-align: center;
		color: var(--white);
		font-size: 18px;
	}
    .sidebar .nav-links li a .link_name{
		color: var(--white);
		font-size: 15px;
		font-weight: 400;
	}
    .out-link{
		margin-top: 150px;
	}
	.main-option{
		background: var(--grey2);
		width: 123px;
	}
    
	
	.pageone{
		background: var(--grey1);
		position: relative;
		min-height: 100vh;
		width: calc(100% - 190px);
		right: 190px;
	}
    .pageone nav{
		height: 50px;
		background: var(--white);
		padding: 0 20px;
		display: flex;
        align-items: center;
        justify-content: space-between;		
	}
	.sidebar-button{
		width: 260px;
	}
    .pageone nav .sidebar-button{
		display: flex;
		align-items: center;
		font-size: 18px;
		font-weight: 500;
	}
    .pageone nav .sidebar-button ion-icon{
		font-size: 27px;
	}
    .pageone nav .search-box{
		height: 40px;
		width: 630px;
		margin: 0 40px;
		position: relative;
	}
	nav .search-box input{
		height:30px;
		width: 595px;
		align-items: center;
		border-radius: 4px;
		margin-top: 5px;
		padding: 10 0px;
		font-size: 18px;
		background: var(--grey1);
		color: var(--black1);
		border: 2px solid var(--grey1);
		outline: none;
	}
    nav .search-box ion-icon{
		position: absolute;
		height: 25px;
		width: 25px;
		margin-top: 8px;
		margin-right: 5px;
		background: #64BBE4;
		color: #fff;
		border-radius: 4px;
		transform: translateY(-3%);
	}
	.home-contine{
		float: right;
		width: 850px;
		height: 415px;
		margin-right: 25px;
		margin-top: 40px;
		background: #fff;
		border-radius: 8px;
		box-shadow: 0 0.5rem 1rem 0 rgba(0, 0, 0, 0.1);
		overflow-y: scroll;
        overflow-x: hidden;
	}
	.home-contine .main-title span{
		color: var(--black1);
		float: right;
		font-size: 18px;
		margin-right: 15px;
		margin-top: 15px;
	}
	
	
	.collapsible-red {
        background-color: #F75F58;
        color: #fff;
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: 2px solid #fff;
        text-align: right;
        outline: none;
        font-size: 12px;
    }
	.active, .collapsible-red:hover {
        background-color: #fff;
		border: 2px solid #F75F58;
		color: #F75F58;
    }
	.collapsible-red  a{
        color: #fff;
        font-weight: bold;		
    }
	.active, .collapsible-red:hover a {
        color: #F75F58;
		font-weight: bold;
    }
	
	.collapsible-bule {
        background-color: #4467F6;
        color: #fff;
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: 2px solid #fff;
        text-align: right;
        outline: none;
        font-size: 12px;	
    }
	.active, .collapsible-bule:hover {
        background-color: #fff;
		border: 2px solid #4467F6;
    }
	.collapsible-bule  a{
        color: #fff;
        font-weight: bold;		
    }
	.active, .collapsible-bule:hover a {
        color: #4467F6;
		font-weight: bold;
    }
	
	.collapsible-yellow {
        background-color: #FAA521;
        color: #fff;
        cursor: pointer;
        padding: 18px;
        width: 100%;
        border: 2px solid #fff;
        text-align: right;
        outline: none;
        font-size: 12px;	
    }
	.active, .collapsible-yellow:hover {
        background-color: #fff;
		border: 2px solid #FAA521;
    }
	.collapsible-yellow  a{
        color: #fff;
        font-weight: bold;		
    }
	.active, .collapsible-yellow:hover a {
        color: #FAA521;
		font-weight: bold;
    }



  </style>

</head>
<body>
    <!-- dashboard barcode start here -->
    <div class="sidebar">
	    <div class="user-details">
		    <ion-icon name="person-circle-outline"></ion-icon>
			<span class="user_name"><?php echo $en; ?></span>
		</div>
		<ul class="nav-links">
		    <li>
			    <a href="#" class="main-option">
				    <ion-icon name="menu-outline"></ion-icon>
					<span class="link_name">خيارات التحكم</span>
				</a>
			</li>
		    <li>
			    <a href="employee.php">
				    <ion-icon name="mail-outline"></ion-icon>
					<span class="link_name">صندوق الوارد</span>
				</a>
			</li>
		    <li>
			    <a href="e_monitoring.php">
				    <ion-icon name="albums-outline"></ion-icon>
					<span class="link_name">صندوق المتابعة</span>
				</a>
			</li>
		    <li>
			    <a href="#">
				    <ion-icon name="create-outline"></ion-icon>
					<span class="link_name">إنشاء مراسلة</span>
				</a>
			</li>
		    <li>
			    <a href="e_achievements.php">
				    <ion-icon name="clipboard-outline"></ion-icon>
					<span class="link_name">تقرير الإنجاز</span>
				</a>
			</li>
		    <li class="out-link">
			    <a href="logout.php">
				    <ion-icon name="log-out-outline"></ion-icon>
					<span class="link_name">تسجيل الخروج</span>
				</a>
			</li>
		</ul>
	</div>
	
	
	
	<!-- page content code start here -->
	<section class="pageone">
	    <nav>
		    <div class="sidebar-button">
				<span class="dashboard">قسم التعيينات والتنقلات</span>
			</div>
		    <div class="search-box">
			    <input type="text" placeholder="  ابحث الآن ...">
				<ion-icon name="search-outline"></ion-icon>
		    </div>
		</nav>
		<div class="home-contine">
		    <div class="main-title">
		        <span>المراسلات الواردة :</span><br><br><br>
                <?php
				    $page_name = "";
                    $i = 0;
                    $sql1 = "select * from procedures where f_id ='$e_id'";
                    $result1 = mysqli_query($conn, $sql1);
                    if($result1)
                    {
						$c_date = date("Y-m-d");
						/*$message = "";*/ 
						
						while($row1 = mysqli_fetch_assoc($result1))
						{
							$diff = "";
							$b_style = "";
					        $color_style = "";
							
							
							$i = $i + 1;
							$id = $row1['id'];
							$registr_no = $row1['registr_no'];
							$subject = $row1['subject'];
							$reply_state = $row1['reply_state'];
							$available_t = $row1['available_t'];
							$sending_d = $row1['sending_d'];
							$f_id = $row1['f_id'];
							
							if($reply_state == "تحتاج")
							{
                                $page_name = "reply.php";
							}
							else
							{
                                $page_name = "noreply.php";								
							}
							
							// Declare and define two dates
                            $date1 = strtotime($sending_d);
                            $date2 = strtotime($c_date);
							
							// Formulate the Difference between two dates
                            $diff = abs($date2 - $date1);
  
                            // To get the year divide the resultant date into
                            // total seconds in a year (365*60*60*24)
                            $years = floor($diff / (365*60*60*24));
 
                            // To get the month, subtract it with years and
                            // divide the resultant date into
                            // total seconds in a month (30*60*60*24)
                            $months = floor(($diff - $years * 365*60*60*24)/ (30*60*60*24));
  
                            // To get the day, subtract it with years and
                            // months and divide the resultant date into
                            // total seconds in a days (60*60*24)
                            $days = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24)/ (60*60*24));
							//$final_days = $days +1;
							//to find button style
							if($available_t>$days){
								$color_style = "#1A7289";
								$b_style = "collapsible-bule";
							}elseif($available_t==$days){
								$color_style = "#22CE39";
								$b_style = "collapsible-yellow";
							}
							else{
								$color_style = "#F75F58";
								$b_style = "collapsible-red";
								$finishing_d = "";
								$condition_m ="غير مكتمل";
								$evaluation = "أقل من المتوقع";
								
	                            $sql = mysqli_query($conn, "SELECT count(*) as total from achievements where registr_no = '".$registr_no."' ")or die(mysqli_error($conn));
	                            $rw = mysqli_fetch_array($sql);
								if($rw['total'] == 0){
									$sql2 = "insert into achievements (f_id, registr_no, subject, sending_d, condition_m, evaluation) values ('$f_id', '$registr_no', '$subject', '$sending_d', '$condition_m', '$evaluation')";
		                            $result = mysqli_query($conn, $sql2);
									
									if($result){
							            $message = "تم الإدراج بنجاح";
						            }
									else{
							            die(mysqli_error($conn));
						            }
								}
							}

							echo '<button type="button" class="'.$b_style.'" ><a href="'.$page_name.'?corr_id='.$id.'" class="list_btn_style">'.$i.')&emsp;'.$registr_no.'&emsp;|&emsp;'.$subject.'&emsp;|&emsp;من :&emsp;'.$days.'- أيام&emsp;</button>';
							
						}
						/*echo $message;*/
					}						
				?>
			</div>
		</div>
	</section>
	
	
	<!-- script link for icon -->
	<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>
</html>
